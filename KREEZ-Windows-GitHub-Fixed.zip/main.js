const { app, BrowserWindow, ipcMain, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

let mainWindow;
const backupDir = () => path.join(app.getPath('userData'), 'backups');
function dayStamp() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function backupFile(day = dayStamp()) { return path.join(backupDir(), `${day}.kreez.enc`); }

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1360, height: 900, minWidth: 980, minHeight: 680,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(() => {
  ipcMain.handle('kreez:backup', async (_event, raw) => {
    if (typeof raw !== 'string' || raw.length > 100 * 1024 * 1024) throw new Error('Invalid backup payload');
    fs.mkdirSync(backupDir(), { recursive: true });
    // Encrypt with Windows DPAPI through Electron safeStorage when available.
    const payload = safeStorage.isEncryptionAvailable()
      ? safeStorage.encryptString(raw)
      : Buffer.from(raw, 'utf8');
    const envelope = Buffer.concat([Buffer.from(safeStorage.isEncryptionAvailable() ? 'KREEZENC1' : 'KREEZRAW1'), payload]);
    const target = backupFile();
    const temp = target + '.' + crypto.randomBytes(4).toString('hex') + '.tmp';
    fs.writeFileSync(temp, envelope);
    fs.renameSync(temp, target);
    return true;
  });
  ipcMain.handle('kreez:restore-latest', async () => {
    const dir = backupDir();
    if (!fs.existsSync(dir)) return null;
    const files = fs.readdirSync(dir).filter(f => /^\d{4}-\d{2}-\d{2}\.kreez\.enc$/.test(f)).sort().reverse();
    if (!files.length) return null;
    const data = fs.readFileSync(path.join(dir, files[0]));
    const header = data.subarray(0, 9).toString('utf8');
    const body = data.subarray(9);
    if (header === 'KREEZENC1') {
      if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows encryption unavailable');
      return safeStorage.decryptString(body);
    }
    if (header === 'KREEZRAW1') return body.toString('utf8');
    throw new Error('Unknown backup format');
  });
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
