# KREEZ CASHIER — Windows build

This folder contains the HTML cashier supplied for this update plus the Electron Windows wrapper and GitHub Actions workflow.

## Build on GitHub
1. Upload **all contents of this folder** to the root of a GitHub repository (not just `index.html`).
2. Open the repository's **Actions** tab and select **Build KREEZ for Windows**.
3. Press **Run workflow** (or push a commit to `main` / `master`).
4. When the run finishes successfully, open its run page, scroll to **Artifacts**, and download **KREEZ-Windows**.
5. Extract the artifact. It contains the Windows installer and portable `.exe`.

## Local build (optional)
Install Node.js 20, then run:
```bash
npm install
npm run dist
```

The app stores its data in the Windows app's persistent user-data folder. Daily backups are written there too. Keep regular exported JSON backups as an additional precaution.

**Important:** This package is assembled from the single HTML file provided in this chat. It does not include any older project files or historical data from another installation. Do not uninstall or reset an existing cashier installation until you have exported and tested a backup from it.
