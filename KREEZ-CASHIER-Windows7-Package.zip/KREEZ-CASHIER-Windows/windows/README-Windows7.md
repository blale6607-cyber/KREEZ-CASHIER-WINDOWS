# KREEZ CASHIER — Windows 7 (32-bit)

- Offline desktop wrapper using Electron 22.3.27 (Chromium 108 generation).
- The installer target is Windows x86 (32-bit).
- Cherry icon included.
- Receipt includes an offline-embedded QR code pointing to https://blale6607-cyber.github.io/Kreez-_links/
- Reports include editable cash-capital input and current inventory cost / retail value / expected margin.
- Data is stored locally by Chromium in the app profile. Export a backup before moving devices.

## Build
Run `npm install`, then `npm run build:win32`.
The GitHub Actions workflow creates a Windows installer artifact.
