# KREEZ CASHIER – Windows

Offline cashier application for KREEZ. Version 3.0 introduces a local SQLite database (`kreez.sqlite`) in the Electron user-data folder. The existing application data model is stored as a SQLite key/value record so the cashier screens can continue using the same data structure while moving persistence out of browser localStorage.

## Build

Open the repository in GitHub and run the `Build KREEZ CASHIER for Windows 7` workflow. It installs dependencies and creates a 32-bit Windows installer.

## Data and backups

- The SQLite database is local to the Windows user profile and works offline.
- Encrypted daily backups are retained by the desktop app when Windows encryption is available.
- Use the in-app export/import backup controls as an additional portable backup.
- Do not delete the app data folder or backups. Keep an extra backup on a USB drive.

## Important

This release is the database foundation. It does not yet provide individual employee accounts or enforce role-based permissions; those are the next implementation stage. UI-level password gates are not a substitute for operating-system account security. Test on the target Windows computer and printer/scanner before using it for live transactions.
