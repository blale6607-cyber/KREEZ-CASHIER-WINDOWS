# KREEZ CASHIER — Windows 7 (32-bit)

- Offline desktop app using Electron 22.3.27 (Windows 7-compatible generation).
- Windows x86 (32-bit) installer; cherry icon included.
- No login and no passwords.
- Purchase cost is not displayed on the cashier sales screen; it is retained for profit calculations.
- If the amount paid is below the invoice total, the difference is added as a discount and printed on the receipt.
- Receipt includes an embedded QR code pointing to the KREEZ Links page.
- Includes inventory, out-of-stock list, expenses, reports, barcode scanning/printing, and backup/restore.
- Data is stored locally in the Windows app profile and is separate from Chrome/Android data. Export a backup before moving devices.

## Build
Run `npm install`, then `npm run build:win32`.
The GitHub Actions workflow creates the Windows installer artifact.
