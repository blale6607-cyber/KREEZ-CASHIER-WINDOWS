const { app, BrowserWindow, Menu, ipcMain, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const initSqlJs = require('sql.js');
let sqlite;
let databasePath;
function persistDatabase() {
  if (!sqlite) throw new Error('Database is not initialized');
  const bytes = sqlite.export();
  const temp = databasePath + '.tmp';
  fs.writeFileSync(temp, Buffer.from(bytes));
  fs.renameSync(temp, databasePath);
}
function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 900, minHeight: 650,
    title: 'KREEZ CASHIER | كريز',
    icon: path.join(__dirname, 'assets', 'cherry.ico'),
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false, contextIsolation: true, sandbox: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

ipcMain.on('kreez:storage-get', (event, key) => {
  try {
    const stmt = sqlite.prepare('SELECT value FROM app_storage WHERE key = ?');
    stmt.bind([String(key)]);
    event.returnValue = stmt.step() ? stmt.getAsObject().value : null;
    stmt.free();
  } catch (e) { event.returnValue = null; }
});
ipcMain.on('kreez:storage-set', (event, key, value) => {
  try {
    const stmt = sqlite.prepare('INSERT INTO app_storage(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
    stmt.run([String(key), String(value)]); stmt.free(); persistDatabase(); event.returnValue = true;
  } catch (e) { event.returnValue = false; }
});
ipcMain.on('kreez:storage-remove', (event, key) => {
  try { const stmt=sqlite.prepare('DELETE FROM app_storage WHERE key=?'); stmt.run([String(key)]); stmt.free(); persistDatabase(); event.returnValue=true; }
  catch(e) { event.returnValue=false; }
});
ipcMain.handle('kreez:daily-backup', async (_event, json) => {
  if (typeof json !== 'string' || json.length > 25 * 1024 * 1024) throw new Error('Invalid backup payload');
  if (!safeStorage.isEncryptionAvailable()) throw new Error('OS encryption unavailable');
  const dir = path.join(app.getPath('userData'), 'backups');
  fs.mkdirSync(dir, { recursive: true });
  const day = new Date().toISOString().slice(0, 10);
  const target = path.join(dir, `KREEZ-${day}.enc`);
  if (!fs.existsSync(target)) {
    const encrypted = safeStorage.encryptString(json);
    fs.writeFileSync(target, encrypted, { mode: 0o600 });
    const files = fs.readdirSync(dir).filter(x => /^KREEZ-\d{4}-\d{2}-\d{2}\.enc$/.test(x)).sort();
    while (files.length > 30) fs.unlinkSync(path.join(dir, files.shift()));
  }
  return { saved: true, file: target };
});
ipcMain.handle('kreez:restore-latest-backup', async () => {
  if (!safeStorage.isEncryptionAvailable()) throw new Error('OS encryption unavailable');
  const dir = path.join(app.getPath('userData'), 'backups');
  if (!fs.existsSync(dir)) return null;
  const files = fs.readdirSync(dir).filter(x => /^KREEZ-\d{4}-\d{2}-\d{2}\.enc$/.test(x)).sort();
  if (!files.length) return null;
  const encrypted = fs.readFileSync(path.join(dir, files[files.length - 1]));
  return safeStorage.decryptString(encrypted);
});

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  databasePath = path.join(app.getPath('userData'), 'kreez.sqlite');
  const SQL = await initSqlJs({ locateFile: file => path.join(__dirname, 'node_modules', 'sql.js', 'dist', file) });
  if (fs.existsSync(databasePath)) sqlite = new SQL.Database(new Uint8Array(fs.readFileSync(databasePath)));
  else sqlite = new SQL.Database();
  sqlite.run('CREATE TABLE IF NOT EXISTS app_storage (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
  persistDatabase();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => { if (sqlite) persistDatabase(); });
