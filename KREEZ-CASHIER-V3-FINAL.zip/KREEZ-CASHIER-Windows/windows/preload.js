const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('kreezDesktop', {
  backup: (json) => ipcRenderer.invoke('kreez:daily-backup', json),
  restoreLatest: () => ipcRenderer.invoke('kreez:restore-latest-backup')
});
contextBridge.exposeInMainWorld('kreezStorage', {
  getItem: (key) => ipcRenderer.sendSync('kreez:storage-get', String(key)),
  setItem: (key, value) => ipcRenderer.sendSync('kreez:storage-set', String(key), String(value)),
  removeItem: (key) => ipcRenderer.sendSync('kreez:storage-remove', String(key))
});
