KREEZ Cashier - Windows build package

This ZIP is structured with package.json at the ZIP root, which fixes the
"package.json not found inside ZIP" error from the previous GitHub Actions run.

Build target: Windows 32-bit (ia32), using Electron 22 for legacy Windows support.
The generated installer is expected under dist/.

To build locally:
  npm install
  npm run dist:win

The app stores its key/value data under Electron's userData folder. Daily backup
files are written under userData/backups; encryption uses Electron safeStorage
when available on the computer.
