const { contextBridge, ipcRenderer } = require('electron');

const storage = {
  getItem: (key) => ipcRenderer.sendSync('kreez-storage-get', String(key)),
  setItem: (key, value) => ipcRenderer.sendSync('kreez-storage-set', String(key), String(value)),
  removeItem: (key) => ipcRenderer.sendSync('kreez-storage-remove', String(key)),
  clear: () => ipcRenderer.sendSync('kreez-storage-clear'),
  key: (index) => ipcRenderer.sendSync('kreez-storage-key', Number(index)),
  get length() { return ipcRenderer.sendSync('kreez-storage-length'); }
};

contextBridge.exposeInMainWorld('kreezStorage', storage);
contextBridge.exposeInMainWorld('kreezDesktop', {
  backup: (jsonText) => ipcRenderer.invoke('kreez-backup', jsonText),
  restoreLatest: () => ipcRenderer.invoke('kreez-restore-latest')
});
