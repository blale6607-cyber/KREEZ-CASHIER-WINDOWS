const { app, BrowserWindow, ipcMain, safeStorage, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

let win;
const values = new Map();
const dataDir = app.getPath('userData');
const storeFile = path.join(dataDir, 'kreez-storage.json');
const backupDir = path.join(dataDir, 'backups');

function loadStore() {
  try {
    const raw = JSON.parse(fs.readFileSync(storeFile, 'utf8'));
    for (const [k, v] of Object.entries(raw)) values.set(k, String(v));
  } catch (_) {}
}
function saveStore() {
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(storeFile, JSON.stringify(Object.fromEntries(values)), 'utf8');
}
function makeWindow() {
  win = new BrowserWindow({
    width: 1200, height: 820, minWidth: 900, minHeight: 650,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(() => { loadStore(); makeWindow(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) makeWindow(); });

ipcMain.on('kreez-storage-get', (event, key) => {
  event.returnValue = values.has(String(key)) ? values.get(String(key)) : null;
});
ipcMain.on('kreez-storage-set', (event, key, value) => {
  values.set(String(key), String(value)); saveStore(); event.returnValue = true;
});
ipcMain.on('kreez-storage-remove', (event, key) => {
  values.delete(String(key)); saveStore(); event.returnValue = true;
});
ipcMain.on('kreez-storage-clear', (event) => {
  values.clear(); saveStore(); event.returnValue = true;
});
ipcMain.on('kreez-storage-key', (event, index) => {
  event.returnValue = Array.from(values.keys())[Number(index)] ?? null;
});
ipcMain.on('kreez-storage-length', (event) => { event.returnValue = values.size; });

ipcMain.handle('kreez-backup', async (_event, jsonText) => {
  try {
    fs.mkdirSync(backupDir, { recursive: true });
    const day = new Date().toISOString().slice(0, 10);
    const plain = Buffer.from(String(jsonText), 'utf8');
    const payload = safeStorage.isEncryptionAvailable()
      ? safeStorage.encryptString(plain.toString('utf8'))
      : plain;
    const suffix = safeStorage.isEncryptionAvailable() ? '.kreezenc' : '.json';
    fs.writeFileSync(path.join(backupDir, `KREEZ-${day}${suffix}`), payload);
    return true;
  } catch (e) { return false; }
});
ipcMain.handle('kreez-restore-latest', async () => {
  try {
    if (!fs.existsSync(backupDir)) return null;
    const files = fs.readdirSync(backupDir)
      .filter(f => f.endsWith('.kreezenc') || f.endsWith('.json'))
      .sort().reverse();
    if (!files.length) return null;
    const file = path.join(backupDir, files[0]);
    const data = fs.readFileSync(file);
    if (files[0].endsWith('.kreezenc')) {
      if (!safeStorage.isEncryptionAvailable()) return null;
      return safeStorage.decryptString(data);
    }
    return data.toString('utf8');
  } catch (_) { return null; }
});
