# KREEZ Cashier — Windows 7 / 32-bit GitHub project

This repository contains the KREEZ cashier app and an Electron wrapper configured for a 32-bit Windows installer. The desktop package uses Electron 22.3.27 and the `ia32` target. Electron 22 is the legacy Electron line intended for Windows 7 compatibility; actual installation and printer behavior must still be tested on the shop PC.

## Build on GitHub
1. Upload **all files and folders in this ZIP** to the root of `blale6607/Kreez-cashier`.
2. Commit to `main` or `master`, or open **Actions → Build KREEZ Windows 32-bit → Run workflow**.
3. After a successful run, download the artifact named `KREEZ-Cashier-Windows-32bit`; it contains the setup `.exe`.

## Local build
Use Node.js 18 and run:

```bash
npm install
npm run dist:win
```

The installer is created in `dist/`.

## Test the HTML
Open `index.html` in a browser. The separate HTML test copy uses CDN-hosted JsBarcode and SheetJS, so an internet connection is needed for barcode and Excel functions. The Electron app uses locally installed npm packages and works offline after installation.

## Importing old data
Before upgrading, open the old program and create its JSON backup using its backup/export screen. Keep the old installation and backup untouched until the new version is verified. In the new program, open **النسخ الاحتياطي** and choose **نقل بيانات النسخة القديمة / استعادة نسخة احتياطية**. The importer accepts KREEZ JSON backups and common wrappers (`db`, `data`, `database`, `state`, `backup`, `payload`, or the `kreez_pos_v1` storage key). It shows record counts and asks for confirmation before replacing the current database. A copy of the current data is placed in the backup text area before replacement.

The importer cannot recover data that exists only inside an inaccessible old application profile; in that case, export a backup from the old program first. Do not uninstall or clear the old app until you have checked products, invoices, suppliers, employees, and reports in the new one.

## Excel inventory
The inventory page includes Excel import, export, and a template. Products are matched by barcode. Imported sold quantity is stored as an opening/reference quantity; the importer does not fabricate historical invoices or sales. Existing invoices and sales remain unchanged.

## Data and verification
Data is stored locally. Windows builds create automatic snapshots in the app's user-data folder. Before daily use, test login/roles, keyboard focus in numeric and password fields, migration from a real old backup, Excel import/export, receipt and split-label printing, scanner input, and backup/restore on the actual Windows 7 32-bit PC. Printer width, paper feed, and cutter behavior depend on the installed driver and device.
