const { app, BrowserWindow, ipcMain, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
let win;
const backupDir = () => path.join(app.getPath('userData'), 'backups');
function atomicWrite(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, data);
  try { if (fs.existsSync(file)) fs.copyFileSync(file, file + '.previous'); } catch (_) {}
  fs.renameSync(tmp, file);
}
function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 850, minWidth: 980, minHeight: 650,
    backgroundColor: '#f7f7f7', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.on('closed', () => { win = null; });
}
ipcMain.handle('kreez:backup', async (_event, json) => {
  if (typeof json !== 'string' || json.length > 100 * 1024 * 1024) throw new Error('Invalid backup payload');
  const dir = backupDir(); fs.mkdirSync(dir, { recursive: true });
  const day = new Date().toISOString().slice(0, 10);
  const target = path.join(dir, `kreez-${day}-${Date.now()}.json`);
  let payload = Buffer.from(json, 'utf8');
  if (safeStorage.isEncryptionAvailable()) payload = safeStorage.encryptString(json);
  atomicWrite(target, payload);
  const files = fs.readdirSync(dir).filter(x => /^kreez-.*\.(json|dat)$/.test(x)).sort().reverse();
  files.slice(30).forEach(name => { try { fs.unlinkSync(path.join(dir, name)); } catch (_) {} });
  return true;
});
ipcMain.handle('kreez:restore-latest', async () => {
  const dir = backupDir(); if (!fs.existsSync(dir)) return null;
  const files = fs.readdirSync(dir).filter(x => /^kreez-.*\.(json|dat)$/.test(x)).sort().reverse();
  if (!files.length) return null;
  const bytes = fs.readFileSync(path.join(dir, files[0]));
  if (safeStorage.isEncryptionAvailable()) {
    try { return safeStorage.decryptString(bytes); } catch (_) {}
  }
  return bytes.toString('utf8');
});
app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (!win) createWindow(); });
