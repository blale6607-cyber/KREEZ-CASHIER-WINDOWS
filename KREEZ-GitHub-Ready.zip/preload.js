const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('kreezDesktop', {
  backup: json => ipcRenderer.invoke('kreez:backup', json),
  restoreLatest: () => ipcRenderer.invoke('kreez:restore-latest')
});
