# KREEZ Cashier

Desktop cashier application built with Electron. The project files are at the repository root so GitHub Actions can build them directly.

## Windows 7 build

- Electron 22.3.27 is retained for legacy Windows compatibility.
- The GitHub Actions workflow builds a 32-bit (IA32) NSIS installer, which is suitable for 32-bit Windows and can also run on 64-bit Windows.
- Build environment: Node.js 18.

## Build locally

```bash
npm install
npm run dist:win
```

The installer is generated in `dist/`.

## Data safety

- Application data is stored in the Electron user data directory.
- The JSON store is written atomically, with a previous-file recovery copy.
- Automatic timestamped snapshots are retained (up to 30 recent snapshots).
- Backups use Electron `safeStorage` encryption when available.

## Notes

Test the installer on the target Windows 7 computer before relying on it in daily operation. Printer output depends on the installed printer driver and paper/label settings; test one receipt/label first.


## تحديث نظام دخول الموظفين
- المدير يضيف لكل موظف اسمًا ظاهرًا واسم مستخدم وPIN من قسم الموظفين.
- الموظف يدخل من زر «دخول الموظف» باستخدام اسم المستخدم والـPIN.
- لا تظهر أقسام الإدارة للموظف، وتُسجل الفاتورة داخليًا باسم الموظف الذي سجل الدخول.
- اسم الموظف لا يُطبع على إيصال العميل؛ يظهر للمدير في سجلات وتقارير الموظفين.
- عند فتح البرنامج يبدأ بطلب دخول موظف، ويمكن إلغاء النافذة ثم دخول المدير.
- بيانات البرنامج الحالية محفوظة محليًا؛ هذا التحديث لا يمسحها. احتفظ بنسخة احتياطية قبل استبدال أي نسخة مستخدمة.
- تم فحص صياغة JavaScript ومعرّفات HTML فقط؛ يلزم اختبار الدخول والبيع والصلاحيات فعليًا على جهاز Windows قبل الاعتماد النهائي.
