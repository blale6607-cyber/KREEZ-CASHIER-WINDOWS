KREEZ Cashier - Windows build package

The ZIP keeps package.json and the application files at the ZIP root for GitHub Actions.

Windows compatibility:
- Electron 22.3.27 is retained for legacy Windows compatibility (including Windows 7).
- The build target is Windows IA32 (32-bit). This installer is suitable for 32-bit Windows 7 and can also run on 64-bit Windows 7.
- Use Node.js 18 for the GitHub Actions/local build environment.

Print improvements:
- Barcode sticker alignment: center, right, or left.
- Horizontal and vertical movement in millimeters.
- Adjustable barcode height, printed product-code size, and price size.
- Code and price remain enabled by default and are included in print layout.
- Existing receipt width, font-size, and margin settings are preserved.

Numeric-field improvements:
- Removed forced refocusing on every click so normal typing/focus is not interrupted.
- Prevented accidental mouse-wheel changes while a numeric field is focused.

To build:
  npm install
  npm run dist:win

The generated installer is expected under dist/.

The app stores its key/value data under Electron's userData folder. Daily backup
files are written under userData/backups; encryption uses Electron safeStorage
when available on the computer.

Important:
- The print output depends on the printer driver and the paper/label dimensions configured there.
- Before printing, use Actual size / 100% and disable Fit to page.
- Always test one sticker first and adjust the horizontal/vertical offsets if needed.
